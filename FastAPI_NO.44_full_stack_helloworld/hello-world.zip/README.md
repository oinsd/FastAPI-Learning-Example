# 前后端分离hello-world（Vue + FastAPI）

## 使用顺序：
### Install axios vue-axios 
```
npm install --save axios vue-axios
```
## Project setup
```
npm install
```
### Compiles and hot-reloads for development
```
npm run serve
```
### Compiles and minifies for production
```
npm run build
```

## 文件修改清单
1、index.html 
2、main.js 
3、App.vue 
